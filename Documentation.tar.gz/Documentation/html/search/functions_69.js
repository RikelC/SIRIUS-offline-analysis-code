var searchData=
[
  ['initialize_5fspectra',['Initialize_Spectra',['../classReadDataFile.html#a0e04a1fc2eea8cc13a515f0bec667680',1,'ReadDataFile']]],
  ['initialize_5fttree',['Initialize_Ttree',['../classReadDataFile.html#a6841c61f031e2a5144b648aab0b1a832',1,'ReadDataFile']]],
  ['is_5fa_5fnew_5frun',['is_a_new_run',['../siriusTest_8cc.html#a4efffbb612efeaf69d3e354094245560',1,'siriusTest.cc']]]
];
