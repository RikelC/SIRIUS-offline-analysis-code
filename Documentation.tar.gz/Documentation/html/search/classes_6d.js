var searchData=
[
  ['myhistograms',['myHistograms',['../classmyHistograms.html',1,'']]]
];
