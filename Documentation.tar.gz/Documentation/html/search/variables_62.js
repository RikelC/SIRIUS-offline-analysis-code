var searchData=
[
  ['blobness',['blobness',['../classReadDataFile.html#a5ab295e7e9b538149ba28c54e0a03850',1,'ReadDataFile']]],
  ['blocksize',['blocksize',['../classReadDataFile.html#a291b7b47c4c34aa929cc137c2f9622e3',1,'ReadDataFile']]],
  ['board',['board',['../classReadDataFile.html#a65ea88ab81d2136ff1d82bdb91365e57',1,'ReadDataFile']]]
];
