var searchData=
[
  ['gain',['gain',['../classReadDataFile.html#adb9d9b1b22eb3cb194b9d94d4e7f0ace',1,'ReadDataFile']]],
  ['gr_5fbaseline',['gr_baseline',['../classmyHistograms.html#a9208e5e6675f32ffa97f099ad6d3e8e9',1,'myHistograms']]]
];
