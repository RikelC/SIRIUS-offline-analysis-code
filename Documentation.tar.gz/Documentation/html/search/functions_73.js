var searchData=
[
  ['save_5fspectra',['Save_Spectra',['../classReadDataFile.html#a4c0fbfd8332ab8140ff3b783e072f7f2',1,'ReadDataFile']]],
  ['save_5fttree',['Save_Ttree',['../classReadDataFile.html#a6f929eda1ef2e5ab5ff4c9d294583053',1,'ReadDataFile']]],
  ['startofglobalrun',['StartOfGlobalRun',['../classReadDataFile.html#a0bfd11fd2427e8ec64086d2f383f28e5',1,'ReadDataFile']]],
  ['startofrun',['StartOfRun',['../classReadDataFile.html#aa6ec0b340e389b2ef4a029bb1c07dccf',1,'ReadDataFile']]]
];
