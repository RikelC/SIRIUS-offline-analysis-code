var searchData=
[
  ['_7emyhistograms',['~myHistograms',['../classmyHistograms.html#a78afa74ade0e988d82ef988f792b030e',1,'myHistograms']]],
  ['_7ereaddatafile',['~ReadDataFile',['../classReadDataFile.html#aec2c21cc0ae54e7774682f063cdd5b12',1,'ReadDataFile']]]
];
