var searchData=
[
  ['deleterawhistograms',['deleteRawHistograms',['../classmyHistograms.html#ad27de25a9e670d660348b7c083e586cd',1,'myHistograms']]]
];
